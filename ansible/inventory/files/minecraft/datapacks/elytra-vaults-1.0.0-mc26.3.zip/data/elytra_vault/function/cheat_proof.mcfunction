# A frame a player places is empty for its first tick, so it is never turned into a vault.
tag @e[type=item_frame,tag=!elytra_vault.seen] add elytra_vault.seen
