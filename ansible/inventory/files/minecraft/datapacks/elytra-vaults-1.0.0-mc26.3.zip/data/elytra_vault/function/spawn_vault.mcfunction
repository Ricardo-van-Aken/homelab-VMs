setblock ^ ^-1 ^ vault{config:{loot_table:"elytra_vault:elytra_vault",key_item:{id:"minecraft:shulker_shell",count:1}},shared_data:{display_item:{id:"minecraft:elytra",count:1}}} replace
summon text_display ^ ^-.25 ^.75 {billboard:"center",text:[{text:"Open With "},{color:"aqua",text:"[Shulker Shell]"}]}
kill @s
