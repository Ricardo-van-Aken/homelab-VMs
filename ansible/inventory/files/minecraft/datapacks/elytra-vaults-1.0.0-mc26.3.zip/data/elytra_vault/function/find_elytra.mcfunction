# An End ship's frame holds its elytra from the first tick it exists.
execute in minecraft:the_end as @e[type=item_frame,tag=!elytra_vault.seen,distance=0..,nbt={Item:{id:"minecraft:elytra"}}] at @s run function elytra_vault:spawn_vault
